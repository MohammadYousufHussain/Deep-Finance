import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# sklearn preprocessing for dealing with categorical variables

from sklearn.preprocessing import LabelEncoder
import sklearn.ensemble
import sklearn.metrics
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve, auc, roc_auc_score, accuracy_score
from sklearn.metrics import average_precision_score, precision_recall_curve, confusion_matrix
from inspect import signature

from sklearn.preprocessing import label_binarize

from sklearn.multiclass import OneVsRestClassifier
from sklearn import svm
from scipy import interp
from itertools import cycle
from sklearn.metrics import classification_report
import pickle

def generate_class(classifier_model):
    
    # load classifier
    loaded_classifier = pickle.load(open(classifier_model, 'rb'))
    # read temp file
    df0 = pd.read_csv('tempfile_3.csv', index_col=0)
    # drop na
    df1 = df0.dropna()
    # initialize out df
    outDF = df1
    # define predicted features
    features = ['LS1'
            ,'LS2','LS3','LS4','LS5','LS6','LS7','LS8','LS9','LS10','LS11','LS12','LS13','LS14','LS15','LS16',
 'LS17','LS18','LS19','LS20','MS1','MS2','MS3','MS4','MS5','MS6','MS7','MS8','MS9','MS10','SS1','SS2','SS3','SS4',
 'SS5', 'BIDASKIMBALANCE']
    # iterate through the feautres and classify
    for f in features:
#        print(np.array(df1[f].values))
        # read the values
        X = np.array(df1[f].values)
        X1 = X.reshape(X.shape[0],1)
        y_score = loaded_classifier.predict_proba(X1)
        localPredict = []
        # determine probability threshold
        for i,j,k in zip(y_score[:,0], y_score[:,1], y_score[:,2]):

            if i > 0.23:
                predict = -1
                localPredict.append(predict)

            elif k > 0.25:
                predict = 1
                localPredict.append(predict)

            else:
                predict = 0
                localPredict.append(predict)

        col_name = f + '_c'
        localPrediction = pd.DataFrame({col_name: localPredict})
        outDF = outDF.join(localPrediction)
    # define classifier features
    features1 = ['LS1_c','LS2_c','LS3_c','LS4_c','LS5_c','LS6_c','LS7_c','LS8_c','LS9_c','LS10_c','LS11_c','LS12_c',
 'LS13_c','LS14_c','LS15_c','LS16_c','LS17_c','LS18_c','LS19_c','LS20_c','MS1_c','MS2_c','MS3_c','MS4_c',
 'MS5_c','MS6_c','MS7_c','MS8_c','MS9_c','MS10_c','SS1_c','SS2_c','SS3_c','SS4_c','SS5_c','BIDASKIMBALANCE_c']
    # select subset of classifier results
    result = outDF[features1]
    # aggregate across columns
    outDF['cum_pred'] = result.sum(axis = 1, skipna = True)
    # define how to select final class for flat
    outcome = pd.DataFrame(np.where((outDF['cum_pred']  >= -1) & (outDF['cum_pred'] <= 1) ,
                                     0, outDF['cum_pred'] ),
                           columns=['PREDICTEDTICKDIR'])
    # define how to select final class for down
    outcome2 = pd.DataFrame(np.where(outcome['PREDICTEDTICKDIR'] < -1, -1, outcome['PREDICTEDTICKDIR']),
                           columns=['PREDICTEDTICKDIR'])
    # define how to select final class for up
    outcome3 = pd.DataFrame(np.where(outcome2['PREDICTEDTICKDIR'] > 1, 1, outcome2['PREDICTEDTICKDIR']),
                           columns=['PREDICTEDTICKDIR'])
    # append the predicted tick in the output DF
    outDF['PREDICTEDTICKDIR'] = outcome3['PREDICTEDTICKDIR']
    # append the predicted tick in the output DF
#    outDF['PREDICTEDTICKDIR'] = outDF['BIDASKIMBALANCE_c']
    # plot predicted tick
    outDF['PREDICTEDTICKDIR'].plot(legend=True, title='PREDICTED TICK DIR')
    # save the file in a temp file
    outDF.to_csv('output_file.csv')
    print("The output file is saved as output_file.csv")
    
def evaluate_classifier_performance():
    # use temp file
    inputData = pd.read_csv('output_file.csv', index_col=0)
    # rename upcycle and down cycle columns
    inputData['TICKDIR'] = inputData.TICKDIR.str.replace('UPCYCLE', 'UP')
    inputData['TICKDIR'] = inputData.TICKDIR.str.replace('DOWNCYCLE', 'DOWN')
    y = inputData.TICKDIR.replace('UP', 1)
    y = y.replace('FLAT', 0)
    y = y.replace('DOWN', -1)
    # use all of the y as test
    y_test = y
    # use predicted tick direction
    localPredict = inputData.PREDICTEDTICKDIR
    # calculate accuracy score
    accuracy = accuracy_score(y_test, localPredict)
    print('The accuracy of the classifier is:', accuracy)
    # calculate the confusion matrix
    confmatrix = confusion_matrix(y_test, localPredict)
    print('The confusion matrix of the classifier is: \n', confmatrix)
    # print performance report
    print(classification_report(y_test, localPredict, labels=[-1,0,1]))
    
 