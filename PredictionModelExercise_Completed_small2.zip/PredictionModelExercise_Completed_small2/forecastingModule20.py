import pandas as pd
import numpy as np
from sklearn import preprocessing
from keras import models
from sklearn.metrics import mean_squared_error
from matplotlib import pyplot

def generate_prediction(file_path, model_name):
    
    # read data from the file
    dataset = pd.read_csv(file_path)
    # extracting a single feature
    X0 = dataset.BIDASKIMBALANCE
    # split into train and test
    train, test = split_dataset3(X0.values)
    # evaluate model and get scores
    n_input = 60
    score, scores, predictions = evaluate_model(train, test, n_input, model_name)
    # summarize scores
    summarize_scores('Best Trained Model', score, scores)
    # plot scores
    days = ['LS1', 'LS2', 'LS3', 'LS4', 'LS5', 'LS6', 'LS7','LS8','LS9','LS10','LS11', 'LS12',
            'LS13', 'LS14', 'LS15', 'LS16', 'LS17','LS18','LS19','LS20']
    pyplot.figure(figsize=(10,5))
    pyplot.plot(days, scores, marker='o', label='Best trained')
    pyplot.title('RMSE of 20-Step Forecast')
    pyplot.legend()
    pyplot.show()
    # return predictions
    return predictions

def rolling_window(a, window):
    shape = a.shape[:-1] + (a.shape[-1] - window + 1, window)
    strides = a.strides + (a.strides[-1],)
    return np.lib.stride_tricks.as_strided(a, shape=shape, strides=strides)

# split a univariate dataset into train/test sets
def split_dataset3(data):
	# split into standard weeks
	max_steps = int(len(data)/20)    
	train, test = data[:60], data[60:(max_steps*20)]
	# restructure into windows of 20-step data
	train = rolling_window(train, 20)
	test = rolling_window(test, 20)
	# place it in a dataframe
	trainDF = pd.DataFrame(data=train)
	testDF = pd.DataFrame(data=test)
	# name columns  
	cols_train = trainDF.columns.tolist()
	cols_test = testDF.columns.tolist()
	# rearrange columns      
	cols_train = cols_train[::-1]
	cols_test = cols_test[::-1]
	# rearrange dataframe   
	trainDF = trainDF[cols_train] 
	testDF = testDF[cols_test]
	# extract values
	train =trainDF.values
	test = testDF.values
	# reshape values    
	train = train.reshape(train.shape[0], train.shape[1], 1) # 1 being the number of features [samples,timesteps, features]
	test = test.reshape(test.shape[0],test.shape[1], 1) # 1 being the number of features [samples,timesteps, features]    
	return train, test

# make a forecast
def forecast(model, history, n_input):
	# flatten data
	data = np.array(history)
	data = data.reshape((data.shape[0]*data.shape[1], data.shape[2]))
	# retrieve last observations for input data
	input_x = data[-n_input:, 0]
	# reshape into [1, n_input, 1]
	input_x = input_x.reshape((1, len(input_x), 1))
	# forecast the next week
	yhat = model.predict(input_x, verbose=0)
	# we only want the vector forecast
	yhat = yhat[0]
	return yhat

# evaluate one or more weekly forecasts against expected values
def evaluate_forecasts(actual, predicted):
	scores = list()
	# calculate an RMSE score for each day
	for i in range(actual.shape[1]):
		# calculate mse
		mse = mean_squared_error(actual[:, i], predicted[:, i])
		# calculate rmse
		rmse = np.sqrt(mse)
		# store
		scores.append(rmse)
	# calculate overall RMSE
	s = 0
	for row in range(actual.shape[0]):
		for col in range(actual.shape[1]):
			s += (actual[row, col] - predicted[row, col])**2
	score = np.sqrt(s / (actual.shape[0] * actual.shape[1]))
	return score, scores

# summarize scores
def summarize_scores(name, score, scores):
	s_scores = ', '.join(['%.1f' % s for s in scores])
	print('%s: [%.3f] %s' % (name, score, s_scores))
    
# evaluate a single model
def evaluate_model(train, test, n_input, model_name):
	# load model
	model = models.load_model(model_name)
	# history is a list of weekly data
	history = [x for x in train]
	# walk-forward validation over each week
	predictions = list()
	for i in range(len(test)):
		# predict the week
		yhat_sequence = forecast(model, history, n_input)
		# store the predictions
		predictions.append(yhat_sequence)
		# get real observation and add to history for predicting the next week
		history.append(test[i, :])
	# evaluate predictions days for each week
	predictions = np.array(predictions)
	score, scores = evaluate_forecasts(test[:, :], predictions)
#	score, scores = 0, 0
	return score, scores, predictions

def struct_20step_predict(predictions):
    #convert array of prediction into a dataframe for 5 step forecasting
    predictionDF = pd.DataFrame(data=predictions, columns=['LS1', 'LS2', 'LS3', 'LS4', 'LS5', 'LS6', 'LS7','LS8',
                                                       'LS9','LS10','LS11', 'LS12',
            'LS13', 'LS14', 'LS15', 'LS16', 'LS17','LS18','LS19','LS20'])
    # place max limit of 1
    predictionDF1 = pd.DataFrame(np.where(predictionDF > 1, 1, predictionDF),columns=['LS1', 'LS2', 'LS3', 'LS4',
                                                                                      'LS5', 'LS6', 'LS7','LS8',
                                                       'LS9','LS10','LS11', 'LS12',
            'LS13', 'LS14', 'LS15', 'LS16', 'LS17','LS18','LS19','LS20'])
    # place min limit of -1 
    predictionDF2 = pd.DataFrame(np.where(predictionDF1 < -1, -1, predictionDF1),columns=['LS1', 'LS2', 'LS3', 'LS4',
                                                                                          'LS5', 'LS6', 'LS7','LS8',
                                                       'LS9','LS10','LS11', 'LS12',
            'LS13', 'LS14', 'LS15', 'LS16', 'LS17','LS18','LS19','LS20'])
    # return dataframe
    return predictionDF2

def join_dataframe(file_path, predictionDF):
    
    #read initial dataframe
    df0 = pd.read_csv(file_path)
    # join dataframe
    df1 = df0.join(predictionDF)
    # save joined dataframe in tempfile
    df1.to_csv('tempfile_1.csv')
    print("20-step forecast saved in tempfile_1.csv")
    
def run_prediction_20(file_path, model_name):
    
    # run prediction function
    predictions = generate_prediction(file_path, model_name)
    # create prediction DF
    predictionDF = struct_20step_predict(predictions)
    # join dataframe
    join_dataframe(file_path, predictionDF)

