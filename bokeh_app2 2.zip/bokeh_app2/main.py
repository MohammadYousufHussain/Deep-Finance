# Pandas for data management
import pandas as pd

# os methods for manipulating paths
from os.path import dirname, join

# Bokeh basics
from bokeh.io import curdoc
from bokeh.models.widgets import Tabs
from bokeh.models.widgets import Div


# Each tab is drawn by one script

from scripts.backtest import equity_tab
from scripts.backtest2 import equity_tab2
from scripts.backtest3 import equity_tab3
from scripts.backtest4 import equity_tab4
from scripts.backtest5 import equity_tab5
from scripts.backtest6 import equity_tab6





# Using included state data from Bokeh for map
from bokeh.sampledata.us_states import data as states

# Read data into dataframes
datapath = (join(dirname(__file__),'data', 'data2.csv'))



# Create each of the tabs

tab1 = equity_tab(datapath)
tab2 = equity_tab2(datapath)
tab3 = equity_tab3(datapath)
tab4 = equity_tab4(datapath)
tab5 = equity_tab5(datapath)
tab6 = equity_tab6(datapath)
#tab7 = equity_tab7(datapath)
#tab8 = equity_tab8(datapath)
#tab9 = equity_tab9(datapath)
#tab10 = equity_tab10(datapath)

div1 = Div(text="""<img align="right" src="bokeh_app2/static/jasminelogo.png" style="width:15%;">""")

curdoc().add_root(div1)

div = Div(text="""<h1 align="center">Social Network Graph Analysis - Business Introduction</h1>""")

curdoc().add_root(div)

# Put all the tabs into one application
tabs = Tabs(tabs = [ tab1, tab2, tab4, tab5, tab6, tab3])

# Put the tabs in the current document for display
curdoc().add_root(tabs)
