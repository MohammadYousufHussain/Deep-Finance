from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

import argparse
import datetime
# os methods for manipulating paths
from os.path import dirname, join


# pandas and numpy for data manipulation
import pandas as pd
import numpy as np

from scipy.stats import gaussian_kde

from bokeh.plotting import figure
from bokeh.models import (CategoricalColorMapper, HoverTool,
						  ColumnDataSource, Panel,
						  FuncTickFormatter, SingleIntervalTicker, LinearAxis, Div)
from bokeh.models.widgets import (CheckboxGroup, Slider, RangeSlider,
								  Tabs, CheckboxButtonGroup,
								  TableColumn, DataTable, Select)
from bokeh.layouts import column, row, WidgetBox, layout
from bokeh.palettes import Category20_16

from collections import Counter
from math import pi

import pandas as pd
import numpy as np

from bokeh.io import output_file, show
from bokeh.palettes import Category20c
from bokeh.plotting import figure
from bokeh.transform import cumsum

from bokeh.core.properties import value
from bokeh.io import show, output_file
from bokeh.models import ColumnDataSource
from bokeh.plotting import figure
from bokeh.transform import dodge

import networkx as nx
from bokeh.io import show, output_file
from bokeh.plotting import figure,show
from bokeh.models.graphs import from_networkx #I haven't been able to use this!
from bokeh.io import output_notebook
from bokeh.models import HoverTool, ColumnDataSource, TapTool, BoxSelectTool
from bokeh.resources import CDN
from bokeh.embed import file_html
from bokeh.models.graphs import from_networkx, NodesAndLinkedEdges, EdgesAndLinkedNodes
from bokeh.models import Plot, Range1d, MultiLine, Circle, HoverTool, BoxZoomTool, ResetTool, WheelZoomTool
from bokeh.palettes import Spectral4, Spectral6, Spectral11
from bokeh.transform import linear_cmap, factor_cmap
from bokeh.models.widgets import Button, RadioButtonGroup, Dropdown
from bokeh.layouts import widgetbox



def equity_tab2(datapath):
    datapath = (join(dirname(__file__), 'scriptsData', 'dataset2clean.csv'))

    df0 = pd.read_csv(datapath)

    edgeList = []

    for b, f in zip(df0.brand, df0.factoryName):
        edgeContainer = [b, f]
        # print(b)
        # print(f)
        edgeList.append(edgeContainer)

    G = nx.Graph()
    G.add_edges_from(edgeList)

    # G = nx.karate_club_graph()

    plot = Plot(plot_width=1500, plot_height=900,
                x_range=Range1d(-1.1, 1.1), y_range=Range1d(-1.1, 1.1))
    plot.title.text = "Interaction Analysis"

    #plot.add_tools(HoverTool(tooltips=[('', '@index')]), TapTool(), BoxSelectTool())

    graph_renderer = from_networkx(G, nx.kamada_kawai_layout, scale=1, center=(0, 0))

    node_size = {k: 0.5 * v for k, v in G.degree()}
    node_size_Value = list(node_size.values())

    val_map = {'Primark': 9.0,
               'MnS': 9.0,
               'PVH': 9.0,
               '''Levis''': 9.0,
               'Adidas': 9.0,
               '''Levis''': 9.0,
               'MnS': 9.0,
               'PVH': 9.0,
               'A First Vina Co., Ltd.': 1.0,
             'AKH Eco Apparels Ltd': 5.0,
             'Altima Textil Laguna SRL de CV': 1.0,
             'Ananta Denim Technology Ltd': 5.0,
             'Ananta Huaxiang Ltd': 5.0,
             'Aquarelle Madagascar S.A': 1.0,
             'BPS Industries - Unit B': 0.0,
             'BPS Industries Unit 28 & 29': 0.0,
             'BRANDIX APPAREL INDIA PVT LTD': 3.0,
             'Bac Giang Garment Corporation': 1.0,
             'Blue Ocean Confeccoes Ltda': 0.0,
             'Bosideng Co Ltd Changshu Garment Factory': 5.0,
             'Canton Unicorn Leather Goods Factory': 0.0,
             'Ceylon Knit Trend (Pvt) Limited': 1.0,
             'ChangZhou QingQing Knitting Factory': 1.0,
             'Changzhou Tooku Garments Co Ltd (Finishing sub factory)': 1.0,
             'Coast to Coast Pvt Ltd': 5.0,
             'Cosmopolitan Industries PVT Ltd': 1.0,
             'Crescent Fashion & Design Limited': 5.0,
             'DOMEX (QUANG NAM) COMPANY LIMITED': 1.0,
             'DONGGUAN QUALITY KNITWEAR LTD': 3.0,
             'Dezhou Excellent Garment MFG Co.,Ltd': 1.0,
             'Dongguan Suscong Healthcare Co Ltd': 5.0,
             'EPYLLION STYLE LTD': 3.0,
             'Eclat Textile Co,. Ltd (Viet Nam)': 1.0,
             'Eishin Co., Ltd Fukushima Factory': 0.0,
             'Everblue Apparels Ltd': 1.0,
             'FOSHAN SHUN DE STRATEGIC GARME': 3.0,
             'FUJIAN DONGFANG LIELANG CLOTHING WEAVING CO.,LTD': 8.0,
             'Fashion Garments 2 Co., Ltd': 1.0,
             'Fashion Garments 2 Co., Ltd (Unit 2)': 1.0,
             'Fashion Garments 2 Co., Ltd - Tan Phu Branch': 1.0,
             'Fook Wah Kun Kee Garment (Shenzhen) Ltd.': 5.0,
             'Four H Apparels Ltd': 5.0,
             'Four H Lingerie Limited': 5.0,
             'Frog Prince Daily Chemical Company Limited': 5.0,
             'Fujian Huaang Sport Goods Co.,Ltd': 8.0,
             'GOLDTEX GARMENTS LTD': 3.0,
             'Gelal Corap Sanayi ve Ticaret A.S. - IST': 0.0,
             'HANGZHOU U-JUMP ARTS & CRAFTS': 3.0,
             'Habitus Fashion Ltd': 5.0,
             'Haining IRIM Leather Co Ltd': 5.0,
             'Haining United Socks Co. Ltd': 0.0,
             'Hangzhou Fanduote Garments,Co Ltd.': 1.0,
             'Hela Clothing (Pvt) Ltd. Thihariya': 1.0,
             'Hirdaramani Garments Katunayake (Pvt) Ltd': 1.0,
             'Hirdaramani Industries Pvt Ltd Kahathuduwa': 1.0,
             'Hirdaramani Mercury Apparel (Pvt) Ltd - Seethawaka- tops&bottoms': 1.0,
             'Hirdaramani Mercury Apparel (Pvt)Ltd Katunayake (new)': 1.0,
             'Hung Long Garment & Service Joint Stock Company': 1.0,
             'Impression Apparel Group S.A. de C.V.': 1.0,
             'Industrias Merlet S.A. DE C.V.': 1.0,
             'Interloop Limited (Hosiery Division I)': 0.0,
             'Interloop Limited HDI': 5.0,
             'Irma Cosmetics Co Ltd': 5.0,
             'JAK GROUP': 0.0,
             'JIAXING NEW REMEI FASHION CO.': 3.0,
             'Jiangsu Suntex Garments Limited': 5.0,
             'Jiaxing Qiselang Garment Co Ltd': 5.0,
             'Jintan Qingqing Knitted Factory': 5.0,
             'KENPARK BANGALDESH APPAREL (PVT.) LTD.(K-2)': 3.0,
             'KWONG WAI HUI DONG KNITTING': 3.0,
             'Karnaphuli Shoes Industries Limited (Garment Unit)': 1.0,
             'Kenpark Bangladesh (Pvt) Ltd (Unit 1)': 1.0,
             'Kenpark Bangladesh Apparel (Pvt) Ltd [K-5]': 1.0,
             'LEGACY FASHIONS LTD.': 3.0,
             'LEXCO CO., LTD.': 0.0,
             'MAS INTIMATES BANGLADESH (PVT) LTD': 3.0,
             'MASOOD TEXTILE MILLS LIMITED': 1.0,
             'MRC Associate Garments (Pvt) Limited': 1.0,
             'Malhas Sonix S.A.': 1.0,
             'Maytex': 1.0,
             'Minh Tri Company Limited': 1.0,
             'Minoronzoni srl': 0.0,
             'NESAN TRIKO KONFEKSIYON': 3.0,
             'NJ Screen Prints': 5.0,
             'Nantong Foremost Headwears Co., Ltd': 0.0,
             'Nishat Mills Limited Apparels Division': 5.0,
             'PANDORA SWEATERS LTD': 3.0,
             'PT Dada Indonesia': 1.0,
             'Pankaj Mercantile Company': 5.0,
             'Pituka Ind Com Benefeciamento De Fios Ltda': 1.0,
             'QUANTUM CLOTHING INDIA PVT LTD': 3.0,
             'RADNIK EXPORTS (186)': 3.0,
             'ROSE SWEATERS LTD. (UNIT - 2)': 3.0,
             'Regina Miracle International Vietnam Co., ltd': 1.0,
             'Regina Miracle Intimate Apparel (Shenzhen) Ltd.': 1.0,
             'Renfro India Private Ltd.': 0.0,
             'Rockline Industries Ltd Redditch': 5.0,
             'Rongcheng Zheng Qinghe': 5.0,
             'Rudong Knitit Fashion Accessory Co Ltd': 5.0,
             'SC BONTIMES SRL': 8.0,
             'SHAHI EXPORTS PVT LTD UNIT 12': 3.0,
             'SONIA AND SWEATERS LTD': 3.0,
             'SOUTH PACIFIC FASHIONS CO., LTD': 3.0,
             'SQUARE FASHIONS LTD': 3.0,
             'Sargam Exports Ltd Plot 152 153': 5.0,
             'Sargam Exports Ltd Plot 210': 5.0,
             'Shanghai QinFa Fashion Co.,Ltd': 5.0,
             'Shaoxing Maidilang Tie & Accessory Co., Ltd': 0.0,
             'Shengzhou Yuelong Tie And Apparel Co Ltd': 5.0,
             'Song Hong Garment JSC - Factory 7.8.9.10': 1.0,
             'Splendid Chance International Ltd': 5.0,
             'Sungkwang Apparels Ltd': 5.0,
             'Sunjin Vina Co.,Ltd': 1.0,
             'Sunrise Fashions': 1.0,
             'Super Performance Textile (Shenzhen) Co., Ltd': 1.0,
             'Supertex S.A.': 1.0,
             'Suzhou Blue Seagull Fashion Co., Ltd': 0.0,
             'THAI PROGRESS GARMENT CO. LTD': 3.0,
             'TNG Investment and Trading JSC- Viet Thai Garment Branch': 1.0,
             'Tanzania Tooku Garments Co Ltd': 5.0,
             'Texport Syndicate I Ltd B3F': 5.0,
             'Texport Syndicate India Ltd Unit 4': 5.0,
             'Thong Thai Textile (Myanmar) Co.,Ltd': 1.0,
             'Thong Thai Textile Co., Ltd.': 1.0,
             'Thuan Phuong Embroideries Garments Company Limited Binh Chanh Factory': 1.0,
             'Tian Run Garment Limited': 5.0,
             'UNITED SWIMWEAR APPAREL CO LTD': 3.0,
             'UPGAIN (VN) MFG CO LTD': 3.0,
             'US Apparel Pvt Ltd Unit 5': 5.0,
             'Ugur Konfeksiyon San Ve Tic As Sapanca': 5.0,
             'Unimas Sportswear': 5.0,
             'V. Fraas GmbH': 0.0,
             'VAS Garment (Thailand) Co., Ltd.': 1.0,
             'VIYELLATEX LIMITED': 3.0,
             'VOGUE TEX( PVT) LTD, KOSGODA.': 3.0,
             'Ventura Bangladesh Ltd': 5.0,
             'Vinty Impex': 5.0,
             'Vogue Tex (Private) Limited. (Kosgoda)': 1.0,
             'Voguetex (Private) Limited': 1.0,
             'WUXI JINMAO GARMENT CO., LTD.': 3.0,
             'World Knits Ltd. (Quartier Militaire)': 1.0,
             'Yancheng Ever-Development Garment & Gifts Co. Ltd.': 5.0,
             'Yantai Langlang Fashion Co Ltd': 5.0,
             'Yixin Xiamen Leather Goods Co Ltd': 5.0,
             'Young Sporting Goods (Suzhou) Co., Ltd.': 0.0,
             'Yupoong Vietnam Co., Ltd.': 0.0,
             'Zhangjiagang Jinxing Garment Co Ltd': 5.0,
             'Zhangjiagang Modat Co Ltd': 5.0,
             'Zhejiang Babei Necktie Weaving Co.,Ltd': 0.0,
             'Zhejiang BangJie Digital Knitting Share Co Ltd': 5.0,
             'Zhejiang Goldtop Hat & Fashion Co Ltd': 5.0,
             'sc Bellarma srl': 0.0
               }

    values = [val_map.get(node, 0.75) for node in G.nodes()]

    size_map = {'Primark': 50.0,
               'MnS': 50.0,
               'PVH': 50.0,
               '''Levis''': 50.0,
               'Adidas': 50.0,
               '''Levis''': 50.0,
               'MnS': 50.0,
               'PVH': 50.0}

    size_values = [size_map.get(node, 25) for node in G.nodes()]

    # add name to node data
    graph_renderer.node_renderer.data_source.data['name'] = list(G.nodes())

    graph_renderer.node_renderer.data_source.data['desire'] = list(values)

    graph_renderer.node_renderer.data_source.data['desire2'] = list(size_values)


    graph_renderer.node_renderer.glyph = Circle(size='desire2', fill_color=linear_cmap('desire', 'Spectral11', 0, 10))
    #graph_renderer.node_renderer.glyph = Circle(size=10,fill_color={'field': 'node_color', 'transform': values})

    graph_renderer.node_renderer.selection_glyph = Circle(size=50, fill_color=Spectral4[2])
    graph_renderer.node_renderer.hover_glyph = Circle(size=50, fill_color=Spectral4[1])

    graph_renderer.edge_renderer.glyph = MultiLine(line_color="#CCCCCC", line_alpha=0.4, line_width=5)
    graph_renderer.edge_renderer.selection_glyph = MultiLine(line_color=Spectral4[2], line_width=5)
    graph_renderer.edge_renderer.hover_glyph = MultiLine(line_color=Spectral4[0], line_width=5)

    # graph_renderer.node_renderer.data_source.data['name'] = [name1, ..., nameN]


    graph_renderer.selection_policy = NodesAndLinkedEdges()
    graph_renderer.inspection_policy = EdgesAndLinkedNodes()
    graph_renderer.inspection_policy = NodesAndLinkedEdges()

    plot.renderers.append(graph_renderer)


    ######################################################################################################

    button1A = Button(label="Number of Brands: 5", button_type="default", width=180)

    panelA = widgetbox(button1A, width= 200)

    ######################################################################################################

    button1B = Button(label="Number of Countries: 25", button_type="warning", width=180)

    panelB = widgetbox(button1B, width= 200)


    ######################################################################################################

    button1C = Button(label="Number of Suppliers: 144", button_type="default", width=180)

    panelC = widgetbox(button1C, width= 200)

    ######################################################################################################

    button1D = Button(label="Number of Connections: 300", button_type="warning", width=180)

    panelD = widgetbox(button1D, width= 200)





    # Create a row layout
    layout1 = layout([[panelA, panelB, panelC, panelD], [plot]])

    # Make a tab with the layout
    tab = Panel(child=layout1, title='Network Analytics')

    return tab

