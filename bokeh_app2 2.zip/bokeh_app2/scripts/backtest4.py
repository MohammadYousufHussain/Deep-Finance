from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

import argparse
import datetime
# os methods for manipulating paths
from os.path import dirname, join


# pandas and numpy for data manipulation
import pandas as pd
import numpy as np

from scipy.stats import gaussian_kde

from bokeh.plotting import figure
from bokeh.models import (CategoricalColorMapper, HoverTool,
						  ColumnDataSource, Panel,
						  FuncTickFormatter, SingleIntervalTicker, LinearAxis, Div)
from bokeh.models.widgets import (CheckboxGroup, Slider, RangeSlider,
								  Tabs, CheckboxButtonGroup,
								  TableColumn, DataTable, Select)
from bokeh.layouts import column, row, WidgetBox, layout
from bokeh.palettes import Category20_16

from collections import Counter
from math import pi

import pandas as pd

from bokeh.io import output_file, show
from bokeh.palettes import Category20c
from bokeh.plotting import figure
from bokeh.transform import cumsum

from bokeh.core.properties import value
from bokeh.io import show, output_file
from bokeh.models import ColumnDataSource
from bokeh.plotting import figure
from bokeh.transform import dodge
from bokeh.palettes import Spectral10, Plasma256, Spectral7
from bokeh.layouts import widgetbox
from bokeh.models.widgets import Button, Dropdown
from bokeh.tile_providers import CARTODBPOSITRON


def equity_tab4(datapath):

    datapath = (join(dirname(__file__), 'scriptsData', 'factorySize.csv'))

    df0 = pd.read_csv(datapath)


    fruits = df0['factoryID'].tolist()
    counts = df0['noOfEmployees'].tolist()

    source = ColumnDataSource(data=dict(fruits=fruits, counts=counts, color=Spectral10))

    plot = figure(x_range=fruits, y_range=(0, 3000), plot_height=400,plot_width=700, title="Employees Count",
               toolbar_location=None, tools="")

    plot.vbar(x='fruits', top='counts', width=0.7, color='color', source=source)

    plot.xgrid.grid_line_color = None
    #p.legend.orientation = "horizontal"
    #p.legend.location = "bottom_center"

    #panelA = widgetbox(plot, width=600)

    #########################################################################################################

    datapath1 = (join(dirname(__file__), 'scriptsData', 'countryFactory.csv'))

    df1 = pd.read_csv(datapath1)

    fruits1 = df1['country'].tolist()
    counts1 = df1['frequency'].tolist()
    countryID1 = df1['id'].tolist()

    source1 = ColumnDataSource(data=dict(fruits1=fruits1, counts1=counts1, countryID1 = countryID1)) #, color1=[Plasma256[0],Plasma256[30],Plasma256[90],
                                                                           #        Plasma256[180],Plasma256[240],Plasma256[10],
                                                                           #        Plasma256[40],Plasma256[70],Plasma256[100],
                                                                           #        Plasma256[130],Plasma256[160],Plasma256[190],
                                                                           #        Plasma256[220],Plasma256[250],Plasma256[20],
                                                                           #        Plasma256[50],Plasma256[80],Plasma256[110],
                                                                           #        Plasma256[140],Plasma256[170],Plasma256[200],
                                                                           #        Plasma256[230],Plasma256[100],Plasma256[10],
                                                                           #        Plasma256[180], Plasma256[240],Plasma256[10],
                                                                           #        Plasma256[130], Plasma256[160],Plasma256[190],
                                                                           #        Plasma256[50], Plasma256[80]]))

    plot1 = figure(x_range=countryID1, y_range=(0, 100), plot_height=400, plot_width=700,
                  title="Distribution by Country",
                  toolbar_location=None, tools="")

    plot1.add_tools(HoverTool(tooltips=[("COUNTRY", "@fruits1"), ("TOTAL", "@counts1")]))

    plot1.vbar(x='countryID1', top='counts1', width=0.7, source=source1)

    plot.xgrid.grid_line_color = None
    # p.legend.orientation = "horizontal"
    # p.legend.location = "bottom_center"

    # panelA = widgetbox(plot, width=600)

    #########################################################################################################

    datapath2 = (join(dirname(__file__), 'scriptsData', 'supplierTypeFreq.csv'))

    df2 = pd.read_csv(datapath2)

    fruits2 = df2['supplierType'].tolist()
    counts2 = df2['frequency'].tolist()

    source1 = ColumnDataSource(
        data=dict(fruits2=fruits2, counts2=counts2))  # , color1=[Plasma256[0],Plasma256[30],Plasma256[90],
    #        Plasma256[180],Plasma256[240],Plasma256[10],
    #        Plasma256[40],Plasma256[70],Plasma256[100],
    #        Plasma256[130],Plasma256[160],Plasma256[190],
    #        Plasma256[220],Plasma256[250],Plasma256[20],
    #        Plasma256[50],Plasma256[80],Plasma256[110],
    #        Plasma256[140],Plasma256[170],Plasma256[200],
    #        Plasma256[230],Plasma256[100],Plasma256[10],
    #        Plasma256[180], Plasma256[240],Plasma256[10],
    #        Plasma256[130], Plasma256[160],Plasma256[190],
    #        Plasma256[50], Plasma256[80]]))

    plot2 = figure(x_range=fruits2, y_range=(0, 110), plot_height=400, plot_width=700,
                   title="Supplier Type Distribution",
                   toolbar_location=None, tools="")
    plot2.add_tools(HoverTool(tooltips=[("TYPE", "@fruits2"), ("TOTAL", "@counts2")]))

    plot2.vbar(x='fruits2', top='counts2', color='green', width=0.7, source=source1)

    plot.xgrid.grid_line_color = None
    # p.legend.orientation = "horizontal"
    # p.legend.location = "bottom_center"

    # panelA = widgetbox(plot, width=600)

    #########################################################################################################

    #button1A = Button(label="My Preferences", button_type="warning")

    menu = [("China", "item_1"), ("Bangladesh", "item_2"), ("Pakistan", "item_3"),
            ("India", "item_4"), ("Sri Lanka", "item_4")]
    dropdown = Dropdown(label="Search Country:", button_type="default", menu=menu)

    #checkbox_groupA = CheckboxGroup(
    #    labels=["Build long term relationships", "Build my brand", "Provide large quantity orders",
    #            "Provide high value orders", "Utilize my downtime", "Utilize unused capacity", ""], active=[])

    #button2A = Button(label="Select", button_type="success")

    panelA = widgetbox(dropdown)


    #########################################################################################################

    # button1A = Button(label="My Preferences", button_type="warning")

    menu1 = [("Accessories", "item_1"), ("Apparel", "item_2"), ("Clothing", "item_3"),
            ("Footwear", "item_4"), ("Not Mentioned", "item_4")]
    dropdown1 = Dropdown(label="Search Type:", button_type="default", menu=menu)

    # checkbox_groupA = CheckboxGroup(
    #    labels=["Build long term relationships", "Build my brand", "Provide large quantity orders",
    #            "Provide high value orders", "Utilize my downtime", "Utilize unused capacity", ""], active=[])

    # button2A = Button(label="Select", button_type="success")

    panelB = widgetbox(dropdown1)

    #########################################################################################################


    # range bounds supplied in web mercator coordinates
    plot3 = figure(x_range=(-2000000, 6000000), y_range=(-1000000, 7000000),plot_height=400, plot_width=700,
               x_axis_type="mercator", y_axis_type="mercator", title="Geographic Location",)
    plot3.add_tile(CARTODBPOSITRON)



    #datapath2 = (join(dirname(__file__), 'scriptsData', 'supplierTypeFreq.csv'))

    #df2 = pd.read_csv(datapath2)

    #fruits2 = df2['supplierType'].tolist()
    counts2 = df2['frequency'].tolist()

    #source1 = ColumnDataSource(
    #    data=dict(fruits2=fruits2, counts2=counts2))  # , color1=[Plasma256[0],Plasma256[30],Plasma256[90],
    #        Plasma256[180],Plasma256[240],Plasma256[10],
    #        Plasma256[40],Plasma256[70],Plasma256[100],
    #        Plasma256[130],Plasma256[160],Plasma256[190],
    #        Plasma256[220],Plasma256[250],Plasma256[20],
    #        Plasma256[50],Plasma256[80],Plasma256[110],
    #        Plasma256[140],Plasma256[170],Plasma256[200],
    #        Plasma256[230],Plasma256[100],Plasma256[10],
    #        Plasma256[180], Plasma256[240],Plasma256[10],
    #        Plasma256[130], Plasma256[160],Plasma256[190],
    #        Plasma256[50], Plasma256[80]]))

    #plot2 = figure(x_range=fruits2, y_range=(0, 110), plot_height=350, plot_width=600,
    #               title="Supplier Type Distribution",
     #              toolbar_location=None, tools="")
    #plot2.add_tools(HoverTool(tooltips=[("TYPE", "@fruits2"), ("TOTAL", "@counts2")]))

    #plot2.vbar(x='fruits2', top='counts2', color='green', width=0.7, source=source1)

    #plot.xgrid.grid_line_color = None
    # p.legend.orientation = "horizontal"
    # p.legend.location = "bottom_center"

    # panelA = widgetbox(plot, width=600)

    #########################################################################################################



    # Create a row layout
    layout1 = layout([[panelA, panelB],[plot, plot3],[plot1,plot2]])

    # Make a tab with the layout
    tab = Panel(child=layout1, title='Manufacturing Sites')

    return tab

