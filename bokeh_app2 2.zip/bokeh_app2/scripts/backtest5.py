from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

import argparse
import datetime
# os methods for manipulating paths
from os.path import dirname, join


# pandas and numpy for data manipulation
import pandas as pd
import numpy as np

from scipy.stats import gaussian_kde

from bokeh.plotting import figure
from bokeh.models import (CategoricalColorMapper, HoverTool,
						  ColumnDataSource, Panel,
						  FuncTickFormatter, SingleIntervalTicker, LinearAxis, Div)
from bokeh.models.widgets import (CheckboxGroup, Slider, RangeSlider,
								  Tabs, CheckboxButtonGroup,
								  TableColumn, DataTable, Select)
from bokeh.layouts import column, row, WidgetBox, layout
from bokeh.models import Button, Dropdown
import pandas as pd
from bokeh.layouts import widgetbox

from math import pi

import pandas as pd

from bokeh.io import output_file, show
from bokeh.palettes import Category20c, Viridis256, Spectral,cividis, inferno, linear_palette, viridis
from bokeh.plotting import figure
from bokeh.transform import cumsum
from bokeh import palettes
from bokeh.transform import linear_cmap





def equity_tab5(datapath):


    datapath = (join(dirname(__file__), 'scriptsData', 'GSCD1.csv'))
    df0 = pd.read_csv(datapath)
    #df0 = df0[0:10]
    #df0 = df0.drop(['UserID'], axis=1)
    #df0 = df0.drop_duplicates()

    subset = df0.loc[df0['country'] == 'Taiwan']
    subsetSummary = pd.DataFrame(subset.groupby(['brand'])['brand'].count())
    subsetSummary = subsetSummary.rename(columns={'brand': 'supplierCount'})
    subsetSummary = subsetSummary.reset_index()

    cols = [TableColumn(field=cl, title=cl) for cl in subsetSummary.columns]

    sourceTable = ColumnDataSource(subsetSummary)

    data_table = DataTable(columns=cols, source=sourceTable, width=875, height=300)






    bt = Button(label='Graphical Representation', width= 600)

    menu = [("China", "China"), ("Bangladesh", "Bangladesh"), ("India", "India"),
            ("South Korea", "SouthKorea"), ("Turkey", "Turkey"),
            ("Taiwan", "Taiwan"), ("Japan", "Japan"), ("Myanmar", "Myanmar"), ("Thailand", "Thailand"),
            ("Vietnam", "Vietnam"), ("Brazil", "Brazil"), ("Italy", "Italy"), ("Portugal", "Portugal"),
            ("Indonesia", "Indonesia"), ("Cambodia", "Cambodia") ]
    dropdown = Dropdown(label="Country:", button_type="primary", menu=menu)
    div = Div(text="Why is the Country interesting and for whom")
    div1 = Div(text=" ")



    value1 = ["Taiwan"]

    countrySelected = pd.DataFrame({"Country:" : value1})

    cols2 = [TableColumn(field=cl, title=cl) for cl in countrySelected.columns]

    sourceCountry = ColumnDataSource(countrySelected)

    data_table2 = DataTable(columns=cols2, source=sourceCountry, width=875, height=50)



    subset3 = df0.loc[df0['country'] == 'Taiwan']
    subsetSummary3 = pd.DataFrame(subset3.groupby(['productType'])['productType'].count())
    subsetSummary3 = subsetSummary3.rename(columns={'productType': 'productTypeCount'})
    subsetSummary3 = subsetSummary3.reset_index()

    cols3 = [TableColumn(field=cl, title=cl) for cl in subsetSummary3.columns]

    sourceTable3 = ColumnDataSource(subsetSummary3)

    data_table3 = DataTable(columns=cols3, source=sourceTable3, width=875, height=300)

    subset4 = df0.loc[df0['country'] == 'Taiwan']
    subsetSummary4 = pd.DataFrame(subset4.groupby(['employeeCount'])['employeeCount'].count())
    subsetSummary4 = subsetSummary4.rename(columns={'employeeCount': 'employeeThreshold'})
    subsetSummary4 = subsetSummary4.reset_index()

    cols4 = [TableColumn(field=cl, title=cl) for cl in subsetSummary4.columns]

    sourceTable4 = ColumnDataSource(subsetSummary4)

    data_table4 = DataTable(columns=cols4, source=sourceTable4, width=875, height=200)

    dataP = subsetSummary
    dataP['angle'] = dataP['supplierCount'] / dataP['supplierCount'].sum() * 2 * pi
    dataP['color'] = Category20c[len(subsetSummary)]

    dataPi = ColumnDataSource(dataP)

    p = figure(plot_width= 600,plot_height=350, title="Supplier Distribution", toolbar_location=None,
               tools="hover", tooltips="@brand: @supplierCount", x_range=(-0.5, 1.0))

    p.wedge(x=0, y=1, radius=0.4,
            start_angle=cumsum('angle', include_zero=True), end_angle=cumsum('angle'),
            line_color="white", fill_color='color', legend='brand', source=dataPi)

    p.axis.axis_label = None
    p.axis.visible = False
    p.grid.grid_line_color = None

    dataP2 = subsetSummary3
    dataP2['angle'] = dataP2['productTypeCount'] / dataP2['productTypeCount'].sum() * 2 * pi
    dataP2['color'] = Category20c[len(subsetSummary3)]

    dataPi2 = ColumnDataSource(dataP2)

    p2 = figure(plot_width=600, plot_height=350, title="Product Distribution", toolbar_location=None,
               tools="hover", tooltips="@productType: @productTypeCount", x_range=(-0.5, 1.0))

    p2.wedge(x=0, y=1, radius=0.4,
            start_angle=cumsum('angle', include_zero=True), end_angle=cumsum('angle'),
            line_color="white", fill_color='color', legend='productType', source=dataPi2)

    p2.axis.axis_label = None
    p2.axis.visible = False
    p2.grid.grid_line_color = None





    panelF = widgetbox(div, dropdown,data_table2, data_table, data_table3, data_table4, width=900)
    panelG = column(div1, bt, p, p2)

    def change_click(attr, old, new):
        print("I was clicked")

        datapath = (join(dirname(__file__), 'scriptsData', 'GSCD1.csv'))
        df0 = pd.read_csv(datapath)

        subset = df0.loc[df0['country'] == dropdown.value]
        subsetSummary = pd.DataFrame(subset.groupby(['brand'])['brand'].count())
        subsetSummary = subsetSummary.rename(columns={'brand': 'supplierCount'})

        sourceTable.data = sourceTable.from_df(subsetSummary)

        subset3 = df0.loc[df0['country'] == dropdown.value]
        subsetSummary3 = pd.DataFrame(subset3.groupby(['productType'])['productType'].count())
        subsetSummary3 = subsetSummary3.rename(columns={'productType': 'productTypeCount'})

        sourceTable3.data = sourceTable3.from_df(subsetSummary3)

        subset4 = df0.loc[df0['country'] == dropdown.value]
        subsetSummary4 = pd.DataFrame(subset4.groupby(['employeeCount'])['employeeCount'].count())
        subsetSummary4 = subsetSummary4.rename(columns={'employeeCount': 'employeeThreshold'})

        sourceTable4.data = sourceTable4.from_df(subsetSummary4)


        value1 = [dropdown.value]
        countrySelected = pd.DataFrame({"Country:": value1})
        sourceCountry.data = sourceCountry.from_df(countrySelected)

        dataP = pd.DataFrame()
        dataP = subsetSummary
        dataP['angle'] = dataP['supplierCount'] / dataP['supplierCount'].sum() * 2 * pi
        custom = viridis(len(subsetSummary))
        dataP['color'] = custom


        dataPi.data = dataPi.from_df(dataP)

        dataP2 = pd.DataFrame()
        dataP2 = subsetSummary3
        dataP2['angle'] = dataP2['productTypeCount'] / dataP2['productTypeCount'].sum() * 2 * pi
        custom = inferno(len(subsetSummary3))
        dataP2['color'] = custom

        dataPi2.data = dataPi2.from_df(dataP2)







    dropdown.on_change('value', change_click)

    bt.on_click(change_click)







    # Create a row layout
    layout1 = layout([[panelF,panelG]])

    # Make a tab with the layout
    tab = Panel(child=layout1, title='Markets Analysis')

    return tab

