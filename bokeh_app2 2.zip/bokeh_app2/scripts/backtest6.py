from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

import argparse
import datetime
# os methods for manipulating paths
from os.path import dirname, join


# pandas and numpy for data manipulation
import pandas as pd
import numpy as np

from scipy.stats import gaussian_kde

from bokeh.plotting import figure
from bokeh.models import (CategoricalColorMapper, HoverTool,
						  ColumnDataSource, Panel,
						  FuncTickFormatter, SingleIntervalTicker, LinearAxis, Div)
from bokeh.models.widgets import (CheckboxGroup, Slider, RangeSlider,
								  Tabs, CheckboxButtonGroup,
								  TableColumn, DataTable, Select)
from bokeh.layouts import column, row, WidgetBox, layout
from bokeh.palettes import Category20_16

from collections import Counter
from math import pi

import pandas as pd

from bokeh.io import output_file, show
from bokeh.palettes import Category20c
from bokeh.plotting import figure
from bokeh.transform import cumsum

from bokeh.core.properties import value
from bokeh.io import show, output_file
from bokeh.models import ColumnDataSource
from bokeh.plotting import figure
from bokeh.transform import dodge

from math import pi

import pandas as pd

from bokeh.io import output_file, show
from bokeh.palettes import Category20c
from bokeh.plotting import figure
from bokeh.transform import cumsum


import pandas as pd

from bokeh.core.properties import field
from bokeh.io import curdoc
from bokeh.layouts import layout
from bokeh.models import (ColumnDataSource, HoverTool, SingleIntervalTicker,
                          Slider, Button, Label, CategoricalColorMapper)
from bokeh.palettes import Category20
from bokeh.plotting import figure

import bokeh as bokeh

#from data import process_data




def equity_tab6(datapath):

    #bokeh.sampledata.download()

    def process_data():
        from bokeh.sampledata.gapminder import fertility, life_expectancy, population, regions

        datapathF = (join(dirname(__file__), 'scriptsData', 'fertility.csv'))
        datapathL = (join(dirname(__file__), 'scriptsData', 'life_expectancy.csv'))
        datapathP = (join(dirname(__file__), 'scriptsData', 'population.csv'))
        datapathR = (join(dirname(__file__), 'scriptsData', 'regions.csv'))

        #fertility.to_csv(datapathF)
        #life_expectancy.to_csv(datapathL)
        #population.to_csv(datapathP)
        #regions.to_csv(datapathR)

        fertility = pd.read_csv(datapathF, index_col='HScode', encoding='utf-8')
        life_expectancy = pd.read_csv(datapathL, index_col='HScode', encoding='utf-8')
        population = pd.read_csv(datapathP, index_col='HScode', encoding='utf-8')
        regions = pd.read_csv(datapathR, index_col='HScode', encoding='utf-8')


        # Make the column names ints not strings for handling
        columns = list(fertility.columns)
        years = list(range(int(columns[0]), int(columns[-1])))
        rename_dict = dict(zip(columns, years))

        fertility = fertility.rename(columns=rename_dict)
        life_expectancy = life_expectancy.rename(columns=rename_dict)
        population = population.rename(columns=rename_dict)
        regions = regions.rename(columns=rename_dict)

        regions_list = list(regions.Group.unique())

        # Turn population into bubble sizes. Use min_size and factor to tweak.
        scale_factor = 200
        population_size = np.sqrt(population / np.pi) / scale_factor
        min_size = 3
        population_size = population_size.where(population_size >= min_size).fillna(min_size)

        return fertility, life_expectancy, population_size, regions, years, regions_list


    fertility_df, life_expectancy_df, population_df_size, regions_df, years, regions_list = process_data()

    #print(fertility_df.head())

    #datapathF = (join(dirname(__file__), 'scriptsData', 'fertilityDF.csv'))
    #fertility_df.to_csv(datapathF)

    #fertility_df1 = pd.read_csv(datapathF, index_col='Country', encoding='utf-8')

    #print(fertility_df1.head())

    df = pd.concat({'fertility': fertility_df,
                    'life': life_expectancy_df,
                    'population': population_df_size},
                   axis=1)

    datapath = (join(dirname(__file__), 'scriptsData', 'targetFile.csv'))

    #df.to_csv(datapath)

    #df = pd.read_csv(datapath)




    data = {}

    regions_df.rename({'Group': 'region'}, axis='columns', inplace=True)
    for year in years:
        df_year = df.iloc[:, df.columns.get_level_values(1) == year]
        df_year.columns = df_year.columns.droplevel(1)
        data[year] = df_year.join(regions_df.region).reset_index().to_dict('series')

    source = ColumnDataSource(data=data[years[0]])

    plot = figure(x_range=(1, 9), y_range=(20, 100), title='Country Export Analysis', plot_height=800, plot_width=1300)
    plot.xaxis.ticker = SingleIntervalTicker(interval=1)
    plot.xaxis.axis_label = "Units Exported (total units)"
    plot.yaxis.ticker = SingleIntervalTicker(interval=20)
    plot.yaxis.axis_label = "Value of Exports (USD)"

    label = Label(x=1.1, y=18, text=str(years[0]), text_font_size='70pt', text_color='#eeeeee')
    plot.add_layout(label)

    color_mapper = CategoricalColorMapper(palette=Category20[14], factors=regions_list)
    plot.circle(
        x='fertility',
        y='life',
        size='population',
        source=source,
        fill_color={'field': 'region', 'transform': color_mapper},
        fill_alpha=0.8,
        line_color='#7c7e71',
        line_width=0.5,
        line_alpha=0.5,
        legend=field('region'),
    )
    plot.add_tools(HoverTool(tooltips="@HScode", show_arrow=False, point_policy='follow_mouse'))

    def animate_update():
        year = slider.value + 1
        if year > years[-1]:
            year = years[0]
        slider.value = year

    def slider_update(attrname, old, new):
        year = slider.value
        label.text = str(year)
        source.data = data[year]

    slider = Slider(start=years[0], end=years[-1], value=years[0], step=1, title="Year")
    slider.on_change('value', slider_update)

    callback_id = None

    def animate():
        global callback_id
        if button.label == '► Play':
            button.label = '❚❚ Pause'
            callback_id = curdoc().add_periodic_callback(animate_update, 200)
        else:
            button.label = '► Play'
            curdoc().remove_periodic_callback(callback_id)

    button = Button(label='► Play', width=60)
    button.on_click(animate)

    layoutP = layout([
        [plot],
        [slider, button],
    ])





    # Create a row layout
    layout1 = layout(layoutP)

    # Make a tab with the layout
    tab = Panel(child=layout1, title='Export Analysis')

    return tab

