from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

import argparse
import datetime
# os methods for manipulating paths
from os.path import dirname, join


# pandas and numpy for data manipulation
import pandas as pd
import numpy as np

from scipy.stats import gaussian_kde

from bokeh.plotting import figure
from bokeh.models import (CategoricalColorMapper, HoverTool,
						  ColumnDataSource, Panel,
						  FuncTickFormatter, SingleIntervalTicker, LinearAxis, Div)
from bokeh.models.widgets import (CheckboxGroup, Slider, RangeSlider,
								  Tabs, CheckboxButtonGroup,
								  TableColumn, DataTable, Select)
from bokeh.layouts import column, row, WidgetBox, layout
from bokeh.palettes import Category20_16

from collections import Counter
from math import pi

import pandas as pd

from bokeh.io import output_file, show
from bokeh.palettes import Category20c
from bokeh.plotting import figure
from bokeh.transform import cumsum

from bokeh.core.properties import value
from bokeh.io import show, output_file
from bokeh.models import ColumnDataSource
from bokeh.plotting import figure
from bokeh.transform import dodge
from bokeh.layouts import widgetbox
from bokeh.models.widgets import CheckboxGroup
from bokeh.models.widgets import Button, RadioButtonGroup, Dropdown
from bokeh.models.widgets import Div



def equity_tab3(datapath):


    button1A = Button(label="My Goals", button_type="warning")

    checkbox_groupA = CheckboxGroup(
        labels=["Expand to new markets", "Expand product offerings", "Find new business opportunities", "Stabilizing my pipeline","" ,"", "" ], active=[])

    button2A = Button(label="Select", button_type="success")

    panelA = widgetbox(button1A, checkbox_groupA, button2A)

    #####################################################################

    button1B = Button(label="My Preferences", button_type="warning")

    checkbox_groupB = CheckboxGroup(
        labels=["Build long term relationships", "Build my brand", "Provide large quantity orders",
                "Provide high value orders", "Utilize my downtime", "Utilize unused capacity", ""], active=[])

    button2B = Button(label="Select", button_type="success")

    panelB = widgetbox(button1B, checkbox_groupB, button2B)

    ######################################################################

    button1C = Button(label="My Services", button_type="warning")

    checkbox_groupC = CheckboxGroup(
        labels=["Label Packaging", "Garment Manufacturing", "Sourcing Services",
                "Garment design", "Fabric development", "Logistic and shipping", "Quality control"], active=[])

    button2C = Button(label="Select", button_type="success")

    panelC = widgetbox(button1C, checkbox_groupC, button2C)

    ######################################################################

    button1D = Button(label="I Am", button_type="primary")

    radio_button_group = RadioButtonGroup(
        labels=["A Buyer", "A Supplier"], active=0)

    menu = [("ABC Garments", "item_1"), ("DEF Garments", "item_2"), ("GHK Garments", "item_3"),
            ("IJM Garments", "item_4"), ("RST Garments", "item_4")]
    dropdown = Dropdown(label="My Company is:", button_type="default", menu=menu)



    panelD = widgetbox(button1D, radio_button_group, dropdown)

    ######################################################################

    div = Div(text="""<h3 align="center">Suggested Matches</h3>""")

    button1E = Button(label="Find Me a Partner", button_type="default")

    panelE = widgetbox(button1E, div, width = 1200)

    ######################################################################

    datapath = (join(dirname(__file__), 'scriptsData', 'companyInformation.csv'))

    df0 = pd.read_csv(datapath)
    df0 = df0.drop(['UserID'], axis=1)
    df0 = df0.drop_duplicates()

    cols = [TableColumn(field=cl, title=cl) for cl in df0.columns]

    data_table = DataTable(columns= cols, source=ColumnDataSource(df0), width=1200, height=400)


    panelF = widgetbox(data_table, width=1200)





    # Create a row layout
    layout1 = layout([[panelD, panelA, panelB, panelC],[panelE], [panelF]])

    # Make a tab with the layout
    tab = Panel(child=layout1, title='Matching Connections')

    return tab

