from __future__ import (absolute_import, division, print_function,
                        unicode_literals)

import argparse
import datetime
# os methods for manipulating paths
from os.path import dirname, join


# pandas and numpy for data manipulation
import pandas as pd
import numpy as np

from scipy.stats import gaussian_kde

from bokeh.plotting import figure
from bokeh.models import (CategoricalColorMapper, HoverTool,
						  ColumnDataSource, Panel,
						  FuncTickFormatter, SingleIntervalTicker, LinearAxis, Div)
from bokeh.models.widgets import (CheckboxGroup, Slider, RangeSlider,
								  Tabs, CheckboxButtonGroup,
								  TableColumn, DataTable, Select)
from bokeh.layouts import column, row, WidgetBox, layout
from bokeh.palettes import Category20_16
from bokeh.transform import linear_cmap

from collections import Counter
from math import pi

import pandas as pd

from bokeh.io import output_file, show
from bokeh.palettes import Category20c
from bokeh.plotting import figure
from bokeh.transform import cumsum

from bokeh.core.properties import value
from bokeh.io import show, output_file
from bokeh.models import ColumnDataSource
from bokeh.plotting import figure
from bokeh.transform import dodge

import networkx as nx

from bokeh.io import show, output_file
from bokeh.models import Plot, Range1d, MultiLine, Circle, HoverTool, TapTool, BoxSelectTool
from bokeh.models.graphs import from_networkx, NodesAndLinkedEdges, EdgesAndLinkedNodes
from bokeh.palettes import Spectral4
from bokeh.plotting import figure, curdoc
from bokeh.layouts import column, row
from bokeh.models import Plot, Range1d, MultiLine, Circle, HoverTool, BoxZoomTool, ResetTool, WheelZoomTool
from bokeh.layouts import widgetbox
from bokeh.models.widgets import CheckboxGroup
from bokeh.models.widgets import Button
from bokeh.models.widgets import Div

import pandas as pd



def equity_tab(datapath):

    datapath = (join(dirname(__file__), 'scriptsData', 'dataset3clean.csv'))

    df0 = pd.read_csv(datapath, encoding = "ISO-8859-1")

    edgeList = []

    for b, f in zip(df0.brand, df0.factoryName):
        edgeContainer = [b, f]
        # print(b)
        # print(f)
        edgeList.append(edgeContainer)

    G = nx.Graph()
    G.add_edges_from(edgeList)



    #G = nx.karate_club_graph()

    plot = Plot(plot_width=1500, plot_height=800,
                x_range=Range1d(-1.1, 1.1), y_range=Range1d(-1.1, 1.1))
    plot.title.text = "Interaction Analysis"

    #plot.add_tools(HoverTool(tooltips=[('','@index')]), TapTool(), BoxSelectTool())

    #graph_renderer = from_networkx(G, nx.random_layout, scale=1, center=(0, 0))
    graph_renderer = from_networkx(G, nx.kamada_kawai_layout, scale=1.0, center=(0,0))

    node_size = {k: 500 * v for k, v in G.degree()}
    node_size_Value = list(node_size.values())

    #nx.set_node_attributes(G, 'node_size', node_size)

    val_map = {'Primark': 1.0,
               'MnS': 1.0,
               'PVH': 1.0,
               '''Levis''': 1.0,
               'Adidas': 1.0,
               '''Levis''': 1.0,
               'MnS': 1.0,
               'PVH': 1.0}

    values = [val_map.get(node, 0.25) for node in G.nodes()]

    graph_renderer.node_renderer.data_source.data['desire'] = list(values)

    size_map = {'Primark': 20.0,
                'MnS': 20.0,
                'PVH': 20.0,
                '''Levis''': 20.0,
                'Adidas': 20.0,
                '''Levis''': 20.0,
                'MnS': 20.0,
                'PVH': 20.0}

    size_values = [size_map.get(node, 5) for node in G.nodes()]

    graph_renderer.node_renderer.data_source.data['desire2'] = list(size_values)


    graph_renderer.node_renderer.glyph = Circle(size='desire2', fill_color=linear_cmap('desire', 'Spectral4', 0, 1))
    #graph_renderer.node_renderer.glyph = Circle(size=10,fill_color=linear_cmap('brand', 'Spectral8', 1, 200))

    graph_renderer.node_renderer.selection_glyph = Circle(size=50, fill_color=Spectral4[2])
    graph_renderer.node_renderer.hover_glyph = Circle(size=50, fill_color=Spectral4[1])

    graph_renderer.edge_renderer.glyph = MultiLine(line_color="#CCCCCC", line_alpha=0.5, line_width=1)
    graph_renderer.edge_renderer.selection_glyph = MultiLine(line_color=Spectral4[2], line_width=1)
    graph_renderer.edge_renderer.hover_glyph = MultiLine(line_color=Spectral4[1], line_width=1)

    #graph_renderer.node_renderer.data_source.data['name'] = [name1, ..., nameN]


    graph_renderer.selection_policy = NodesAndLinkedEdges()
    graph_renderer.inspection_policy = EdgesAndLinkedNodes()
    graph_renderer.inspection_policy = NodesAndLinkedEdges()

    plot.renderers.append(graph_renderer)

    ######################################################################################################

    button1A = Button(label="Number of Brands: 5", button_type="default", width=180)

    panelA = widgetbox(button1A, width=200)

    ######################################################################################################

    button1B = Button(label="Number of Countries: 25", button_type="warning", width=180)

    panelB = widgetbox(button1B, width=200)

    ######################################################################################################

    button1C = Button(label="Number of Suppliers: 3680", button_type="default", width=180)

    panelC = widgetbox(button1C, width=200)

    ######################################################################################################

    button1D = Button(label="Number of Connections: 3837", button_type="warning", width=180)

    panelD = widgetbox(button1D, width=200)





    # Create a row layout
    layout1 = layout([[panelA, panelC, panelD], [plot]])

    # Make a tab with the layout
    tab = Panel(child=layout1, title= 'Network Overview')

    return tab

